package com.transportejava.transporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransporteApplicationTests {

	@Test
	void contextLoads() {
	}

}
